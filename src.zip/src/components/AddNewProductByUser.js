import React from 'react';

const AddNewProductByUser = () => {
  return (
    <section>
      sfdfdf
    </section>
  );
};

export default AddNewProductByUser;