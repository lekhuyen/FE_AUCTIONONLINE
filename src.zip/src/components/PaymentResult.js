import React from "react";

const PaymentResult = () => {

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gray-100">
      success
    </div>
  );
};

export default PaymentResult;