import React from "react";

export const PrivateRoute = ({ children }) => {
  return <div>{children}</div>;
};
