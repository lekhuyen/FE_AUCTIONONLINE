import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ProductSalesPage = () => {
  // State để lưu trữ dữ liệu sản phẩm đã bán
  const [productSales, setProductSales] = useState([]);
  axios.defaults.baseURL = 'http://localhost:8080'; // URL backend của bạn

  // Gọi API để lấy thống kê sản phẩm
  useEffect(() => {
    const fetchProductSales = async () => {
      try {
        const response = await axios.get('/api/admin/sales/products');
        setProductSales(response.data); // Lưu kết quả trả về vào state
      } catch (error) {
        console.error("Lỗi khi tải thống kê sản phẩm:", error);
      }
    };

    fetchProductSales();
  }, []);

  return (
    <div className="product-sales">
      <h1>Thống kê Sản phẩm đã bán</h1>
      
      {/* Bảng hiển thị thống kê sản phẩm */}
      <table className="table">
        <thead>
          <tr>
            <th>Sản phẩm</th>
            <th>Số lượng bán</th>
            <th>Doanh thu</th>
          </tr>
        </thead>
        <tbody>
          {productSales.map((sale) => (
            <tr key={sale.productId}>
              <td>{sale.productId}</td> {/* Sử dụng tên sản phẩm nếu có */}
              <td>{sale.totalQuantity}</td>
              <td>{sale.totalRevenue}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ProductSalesPage;
